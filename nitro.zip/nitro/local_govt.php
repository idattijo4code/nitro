<?php require_once('Connections/connection.php'); 

    $id = $_GET['state_id'];
	$sql = "select * from local_govt where state_id = '$id';";
	$query = mysql_query($sql);
	$count = mysql_num_rows($query);
	if($count==0)
	{
		echo '<option value="">--Select Local Govt--</option>';
	}
	else 
	{
		while($row = mysql_fetch_array($query)){
		echo '<option value="'.$row["lg_id"].'">'.$row["local_govt"].'</option>';
		}
	}
?>