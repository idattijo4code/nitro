<?php require_once('Connections/connection.php'); ?>
<?php session_start(); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php include('assets/inc/header.inc'); ?>
<html>
<head>
<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript">
$(function(){
		$("#state").change(function(){
			$.get("local_govt.php", {state_id:$("#state").val()}, function(data){
		   	$("#lga").html(data);
				});
				return false;
			});
		});

</script>

</head>
<body>
<?php
mysql_select_db($database_connection, $connection);
$query_state = "SELECT * FROM states ";
$state = mysql_query($query_state, $connection) or die(mysql_error());
$row_state = mysql_fetch_assoc($state);
$totalRows_state = mysql_num_rows($state);
?>


    <div id="wrapper">
        <!--<nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
               <!-- <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="assets/img/portfolio/b.jpg" height="500" width="150"></a>
            </div>

            <div class="header-right">

              <a href="message-task.html" class="btn btn-info" title="New Message"><b>30 </b><i class="fa fa-envelope-o fa-2x"></i></a>
                <a href="message-task.html" class="btn btn-primary" title="New Task"><b>40 </b><i class="fa fa-bars fa-2x"></i></a>
                <a href="login.html" class="btn btn-danger" title="Logout"><i class="fa fa-exclamation-circle fa-2x"></i></a>


            </div>
        </nav>-->
        <!-- /. NAV TOP  -->
       <?php include('assets/inc/nav.inc'); ?>
        <!-- /. NAV SIDE  -->
         <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Personal Information</h1>
                        <h1 class="page-subhead-line">Kindly provide your personal information below:</h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        
                        <div class="panel-body">
                            <form role="form" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label>Surname</label>
                                            <input class="form-control" type="text" placeholder="Enter your Surname">
                                        </div>
                                        <div class="form-group">
                                            <label>First Name</label>
                                            <input class="form-control" type="text" placeholder="Enter your First Name">
                                        </div>
                                        <div class="form-group">
                                            <label>Other Names</label>
                                            <input class="form-control" type="text" placeholder="Provide Other Names (if any)">
                                        </div>
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input class="form-control" type="text" placeholder="Enter your username">
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input class="form-control" type="password" placeholder="Provide your password)">
                                        </div>
                                        <div class="form-group">
                                            <label>Gender</label>
                                            <select class="form-control">
                                                <option>-Select-</option>
                                                <option>Male</option>
                                                <option>Female</option>
                                                <option>Others</option>
                                            </select>
                                        </div>                                   
                                        <div class="form-group">
                                            <label>Date of Birth</label>
                                            <input class="form-control" type="Date" placeholder="Enter your Correct Date of Borth">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Residential Address</label>
                                            <textarea class="form-control"></textarea>
                                        </div>  
                                        
                                           <div class="form-group">
                                            <label>State</label>
                                            <select class="form-control" id="state" name="state">
                                                <option>-Select State-</option>
                                      <?php 
							  $sql= "select * from states;";
							  $query = mysql_query($sql);
							  while($row = mysql_fetch_array($query))
							  {
								  echo '<option value="'.$row["state_id"].'">'.$row["state"].'</option>';
							  }
					               ?>
                                            </select>
                                        </div>   
                                         <div class="form-group">
                                            <label>L.G.A</label>
                                            <select class="form-control" id="lga" name="lga">
                                                <option>-Select-</option>
                                                
                                            </select>
                                        </div> 
                                        <div class="form-group">
                                            <label>Phone Number</label> 
                                            <input class="form-control" type="text" placeholder="Enter your phone number">
                                        </div> 
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" type="email" placeholder="Enter your Email">
                                        </div> 
                             <h1 class="page-subhead-line">Kindly provide information of your Next of Kin below:</h1>                                         
                                        <div class="form-group">
                                            <label>Names</label>
                                           <input class="form-control" type="text" placeholder="Enter your phone number">                                        </div>  
                                            
                                          <div class="form-group">
                                            <label>Address</label>
                                          <textarea class="form-control"></textarea>
                                        </div>
                                          <div class="form-group">
                                            <label>Relatiosnship</label>
                                             <select class="form-control">
                                                <option>-Select-</option>
                                                <option>Father</option>
                                                <option>Mother</option>
                                                <option>Brother</option>
                                                <option>Others</option>
                                            </select>
                                                
                                            </div>
                                                                         
                                        <div class="form-group">
                                            <label>Email Address</label>
                                            <input class="form-control" type="Email">
                                        </div>
                                        <div class="form-group">
                                            <label>Phone Number</label>
                                            <input class="form-control" type="text">
                                        </div> 
                             <h1 class="page-subhead-line">Kindly provide information of your Refreer:</h1> 
                                
                              <div class="form-group">
                                            <label>Email Address</label>
                                            <input class="form-control" type="Email">
                                        </div>
                                        <div class="form-group">
                                            <label>Phone Number</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Residential Address</label>
                                            <textarea class="form-control"></textarea>
                                        </div>                    
                                        <button type="button" class="btn btn-info">Submit</button>
                                        <button type="reset" class="btn btn-info">Reset</button>
                                </form>
                            </div>
                        </div>
                            </div>
<!--<div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-danger">
                        <div class="panel-heading">
                           SINGUP FORM
                        </div>
                        <div class="panel-body">
                            <form role="form">
                                        
                                 <div class="form-group">
                                            <label>Enter Email</label>
                                            <input class="form-control" type="text">
                                     <p class="help-block">Help text here.</p>
                                        </div>
                                            <div class="form-group">
                                            <label>Enter Password</label>
                                            <input class="form-control" type="password">
                                     <p class="help-block">Help text here.</p>
                                        </div>
                                <div class="form-group">
                                            <label>Re Type Password </label>
                                            <input class="form-control" type="password">
                                     <p class="help-block">Help text here.</p>
                                        </div>
                                 
                                        <button type="submit" class="btn btn-danger">Register Now </button>

                                    </form>
                            </div>
                        </div>
                            </div>
        </div>-->
             <!--/.ROW-->
             <!--<div class="row">
                 <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-primary">
                        <div class="panel-heading">
                           FORM ELEMENTS
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                            <label>Select Example</label>
                                            <select class="form-control">
                                                <option>One Vale</option>
                                                <option>Two Vale</option>
                                                <option>Three Vale</option>
                                                <option>Four Vale</option>
                                            </select>
                                        </div>
                            <hr>
                            <div class="form-group">
                                            <label>Multiple Select Example</label>
                                            <select multiple="" class="form-control">
                                                <option>One Vale</option>
                                                <option>Two Vale</option>
                                                <option>Three Vale</option>
                                                <option>Four Vale</option>
                                            </select>
                                        </div>
                            <hr>
                            <div class="form-group">
                                            <label>Checkboxes</label>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Checkbox Example One
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Checkbox Example Two
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Checkbox Example Three
                                                </label>
                                            </div>
                                  <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" value="">Checkbox Example Four
                                                </label>
                                            </div>
                                        </div>
                            <hr>
                            <div class="form-group">
                                            <label>Radio Button Examples</label>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked="">Radio Example One
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">Radio Example Two
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="optionsRadios" id="optionsRadios3" value="option3">Radio Example Three
                                                </label>
                                            </div>
                                        </div>
                            </div>
                        </div>
                            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-default">
                        <div class="panel-heading">
                           OTHER ELEMENTS FOR FORM
                        </div>
                        <div class="panel-body">
                            
                            <form role="form">
                                Some Message Examples
                                <br />
                                        <div class="form-group has-success">
                                            <label class="control-label" for="success">SUCCESS EXAMPLE</label>
                                            <input type="text" class="form-control" id="success" />
                                        </div>
                                        <div class="form-group has-warning">
                                            <label class="control-label" for="warning">WARNING EXAMPLE</label>
                                            <input type="text" class="form-control" id="warning" />
                                        </div>
                                        <div class="form-group has-error">
                                            <label class="control-label" for="error">ERROR EXAMPLE</label>
                                            <input type="text" class="form-control" id="error" />
                                        </div>
                                    </form>
                            <hr>
                            Other Group Examples
                            <br>
                            <form role="form">
                                  <div class="input-group">
      <span class="form-group input-group-btn">
        <button class="btn btn-default" type="button">Go!</button>
      </span>
      <input type="text" class="form-control" />
    </div>
<br />
                                           <div class="input-group">
     
      <input type="text" class="form-control" />
                                                <span class="form-group input-group-btn">
        <button class="btn btn-default" type="button">Go!</button>
      </span>
    </div>
                                         </form>
                            <hr>
                            <form role="form">
                                            <div class="form-group">
                                                <label for="disabledInput">Disabled input</label>
                                                <input class="form-control" id="disabledInput" type="text" placeholder="Disabled input" disabled="">
                                            </div>
                                            
                                            
                                    </form>
                            <hr />
                            For more customization for this template or its components please visit official bootstrap website i.e getbootstrap.com or
                            <a href="http://getbootstrap.com/components/" target="_blank">click here</a> 
                            </div>
                        </div>
                            </div>-->

        </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
   <?php include('assets/inc/footer.inc'); ?>


</body>
</html>
<?php
mysql_free_result($state);

//mysql_free_result($lga);

?>
