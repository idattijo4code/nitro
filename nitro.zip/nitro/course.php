<?php require_once('Connections/connection.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
if (!isset($_SESSION['MM_Username']))
  {
  	header("location: Index.php");
  }
}
	$id = $_GET['state_id'];
mysql_select_db($database_admission_portal, $admission_portal);
$sql = "SELECT * FROM states WHERE state_id = '$id'";
$query = mysql_query($sql, $admission_portal) or die(mysql_error());
$count = mysql_num_rows($query);
/*?>
<?php require("connections/connetio.php");
	$id = $_GET['state_id'];

	$sql = "select * from local_govt where state_id = '$id';";
	$query = mysql_query($sql, $);
	$count = mysql_num_rows($query);*/
	if($count==0)
	{
		echo '<option value="">--Select State--</option>';
	}
	else 
	{
		while($row = mysql_fetch_array($query)){
		echo '<option value="'.$row["lg_id"].'">'.$row["states"].'</option>';
		}
	}
?>
